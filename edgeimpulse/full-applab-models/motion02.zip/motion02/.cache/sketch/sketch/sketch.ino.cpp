#include <Arduino.h>
#line 1 "/home/arduino/ArduinoApps/motion01/sketch/sketch.ino"
// You might have to delete the "Arduino_LSM6DS3" library and 
// Install the "Seeed Arduino LSM6DS3"

#include <LSM6DS3.h>
#include <Wire.h>
#include <Arduino_RouterBridge.h>

#define Serial Monitor

// Create IMU object using I2C interface
LSM6DS3 myIMU(I2C_MODE, 0x6A);

float accelX, accelY, accelZ;
//float gyroX, gyroY, gyroZ;

unsigned long previousMillis = 0; // Stores last time values were updated
const long interval = 16;         // Interval at which to read (16ms) - sampling rate of 62.5Hz and should be adjusted based on model definition
//int has_movement = 0;             // Flag to indicate if movement data is available

#line 20 "/home/arduino/ArduinoApps/motion01/sketch/sketch.ino"
void setup();
#line 50 "/home/arduino/ArduinoApps/motion01/sketch/sketch.ino"
void loop();
#line 20 "/home/arduino/ArduinoApps/motion01/sketch/sketch.ino"
void setup() {
  Bridge.begin();


  Serial.begin(115200);
 // while (!Serial) delay(10);

  Serial.print("XIAOML Kit IMU Test");
  Serial.print("LSM6DS3TR-C 6-Axis IMU");
  Serial.print("====================");

  // Initialize the IMU
  if (myIMU.begin() != 0) {
      Serial.print("ERROR: IMU initialization failed!");
      while(1) delay(1000);
  } else {

      Serial.print("X, Y, Z" );
  }


  

}






void loop() {
  unsigned long currentMillis = millis(); // Get the current time

  if (currentMillis - previousMillis >= interval) {
    // Save the last time you updated the values
    previousMillis = currentMillis;

    // Read new movement data from the sensor
  //  has_movement = movement.update();
  //  if(has_movement == 1) {
      // Read accelerometer data (in g-force)
      accelX = myIMU.readFloatAccelX();
      accelY = myIMU.readFloatAccelY();
      accelZ = myIMU.readFloatAccelZ();
      Serial.print(String(accelX,3) + ", " +  String(accelY,3) + ", " + String(accelZ,3)  );
      
      Bridge.notify("record_sensor_movement", accelX, accelY, accelZ);      
    
    
  }
}
