# SPDX-FileCopyrightText: Copyright (C) 2025 ARDUINO SA <http://www.arduino.cc>
#
# SPDX-License-Identifier: MPL-2.0

from arduino.app_bricks.motion_detection import MotionDetection
from arduino.app_utils import App, Bridge

# Initialize the motion detection brick
motion_detection = MotionDetection(confidence=0.4)

# --- Function to handle incoming sensor data from the C++ Sketch ---
def record_sensor_movement(x: float, y: float, z: float):
    """
    Receives accelerometer data (in g) from the Sketch, converts it to m/s^2, 
    and feeds it to the motion detection model.
    """
    # The sensor provides values in g (gravitational acceleration). 
    # The model expects values in m/s^2 (multiply by 9.81).
    g = 9.81 
    x = x * g
    y = y * g
    z = z * g
    
    # Send the converted sample to the motion detection model brick
    motion_detection.accumulate_samples((x, y, z))

# The Python side provides this function, which is called by Bridge.notify() 
# on the C++ side.
Bridge.provide("record_sensor_movement", record_sensor_movement)

# --- Function to handle successful movement detection ---
def on_updown_movement_detected(classification: dict):
    """
    Callback function that handles a detected movement classification.
    It calls back to the C++ Sketch to trigger an action.
    """
    detected_label = classification.get('label', 'unknown')
    
    print(f"Movement detected! Label: {detected_label}")
    
    # IMPORTANT: Call a function on the C++ side to trigger a reaction 
    # (e.g., light an LED, print a message on the serial monitor).
    # We pass the detected label so the Sketch can react differently 
    # based on the type of movement.
    Bridge.call("movement_detected", detected_label)

# Register actions for all expected movement classes
motion_detection.on_movement_detection('1upflat', on_updown_movement_detected)
motion_detection.on_movement_detection('2leftside', on_updown_movement_detected)
motion_detection.on_movement_detection('3facing', on_updown_movement_detected)

App.run()