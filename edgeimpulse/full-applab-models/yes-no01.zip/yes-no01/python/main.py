# SPDX-FileCopyrightText: Copyright (C) 2025 ARDUINO SA <http://www.arduino.cc>
#
# SPDX-License-Identifier: MPL-2.0

from arduino.app_utils import *
from arduino.app_bricks.keyword_spotting import KeywordSpotting

def on_keyword_detected():
    """Callback function that handles a detected keyword."""
    Bridge.call("keyword_detected")

spotter = KeywordSpotting()
spotter.on_detect("yes", on_keyword_detected)
spotter.on_detect("no", on_keyword_detected)

App.run()
